$('#from').bind('input propertychange', function () {
    convert()
})
$('#format').bind('input propertychange', function () {
    convert()
})